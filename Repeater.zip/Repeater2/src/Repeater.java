
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Repeater {

    public static void main(String[] args) {
        if (args.length > 0) {
            String currentDirectory = System.getProperty("user.dir");
            System.out.println("Current Directory: " + currentDirectory);
            String infile = currentDirectory + "/in";
            String outfile = currentDirectory + "/out";
            String maskfile = currentDirectory + "/mask";
            int kmer = 12;
            int minlen = 50;
            boolean maskshow = true;
            boolean seqshow = true;
            int flangsshow = 0;
            boolean quickshow = true;
            boolean ssrrun = false;

            System.out.println("Command-line arguments:");
            infile = args[0];
            outfile = args[0] + ".out";
            maskfile = args[0] + ".mask";

            String s = String.join(" ", args).toLowerCase() + " ";
            if (s.contains("mask=false")) {
                maskshow = false;
                System.out.println("Shown Mask is " + maskshow);
            }
            if (s.contains("seqshow=false")) {
                seqshow = false;
                System.out.println("Shown repeated sequence is " + seqshow);
            }

            if (s.contains("quick=false")) {
                quickshow = false;
                System.out.println("Quick analysis is " + quickshow);
            }
            if (s.contains("ssr=true")) {
                ssrrun = true;
                System.out.println("SSR analysis is " + ssrrun);
            }
            if (s.contains("flanks=")) {
                flangsshow = 0;
                int j = s.indexOf("flanks=");
                int x = s.indexOf(" ", j);
                if (x > j) {
                    flangsshow = StrToInt(s.substring(j + 5, x));
                }
                if (flangsshow < 0) {
                    flangsshow = 0;
                }
                if (flangsshow > 100) {
                    flangsshow = 100;
                }
                System.out.println("Flanks around repeat =" + flangsshow);
            }
            if (s.contains("kmer=")) {
                int j = s.indexOf("kmer=");
                int x = s.indexOf(" ", j);
                if (x > j) {
                    kmer = StrToInt(s.substring(j + 5, x));
                }
                if (kmer < 5) {
                    kmer = 5;
                }
                System.out.println("kmer=" + kmer);
            }

            if (s.contains("min=")) {
                int j = s.indexOf("min=");
                int x = s.indexOf(" ", j);
                if (x > j) {
                    minlen = StrToInt(s.substring(j + 4, x));
                }
                if (minlen < kmer) {
                    minlen = kmer;
                }
                System.out.println("Minimal string length filter=" + minlen);
            }

            try {
                long startTime = System.nanoTime();
                byte[] binaryArray = Files.readAllBytes(Paths.get(infile));
                ReadingSequencesFiles rf = new ReadingSequencesFiles(binaryArray);
                System.out.println("Target sequence length = " + rf.getLength() + " nt");
                System.out.println("Running...");
                Tandems s2 = new Tandems();
                s2.SetSequences(rf.getSequences(), rf.getNames());
                s2.SetKmerLen(kmer);
                s2.SetTandemLen(minlen);
                s2.SetMasked(maskshow);
                s2.SetMaskFileName(maskfile);
                s2.SetShowSeq(seqshow);
                s2.SetFlanks(flangsshow);
                s2.SetQuickReports(quickshow);
                s2.SetCurrentFileName(infile);
                s2.SetFileName(outfile);
                if (ssrrun) {
                    s2.SetTelomers(true);
                    s2.RunSSR();
                } else {
                    s2.Run();
                }
                System.out.println("Target file name: " + infile);
                System.out.println("Result file name: " + outfile);
                if (maskshow) {
                    System.out.println("Masked file name: " + maskfile);
                }
                long duration = (System.nanoTime() - startTime) / 1000000000;
                System.out.println("Time taken: " + duration + " seconds");
            } catch (IOException e) {
                System.out.println("The file name is incorrect.");
            }
        } else {
            System.out.println("REPEATER v2 (2023) by Ruslan Kalendar\nhttps://primerdigital.com/tools/\n");
            System.out.println("Basic usage:");
            System.out.println("java -jar \\Repeater2\\dist\\Repeater2.jar <inputfile> optional_commands");
            System.out.println("Common options:");
            System.out.println("kmer=5\t minimal kmer=5 (default 12)");
            System.out.println("min=50\t minimal repeat lenghth is kmer length (default min=50)");
            System.out.println("flanks=100\t extend the flanks of the repeat with an appropriate length (100 nt) (default flanks=0)");
            System.out.println("mask=true/false\t generate a new file with masking repeats (default mask=true)");
            System.out.println("seqshow=true/false\t extract repeat sequences (default seqshow=false)");
            System.out.println("quick=true/false\t quick analysis of repeats, without deep analysis and their clustering (default quick=true)");
            System.out.println("ssr=true\t analyzing only the SSR/telomers loci (default ssr=false)\n");
            System.out.println("java -jar \\Repeater2\\dist\\Repeater2.jar <inputfile> kmer=21 min=21 quick=false mask=false seqshow=true");
        }
    }

    public static int StrToInt(String str) {
        StringBuilder r = new StringBuilder();
        int z = 0;
        r.append(0);
        for (int i = 0; i < str.length(); i++) {
            char chr = str.charAt(i);
            if (chr > 47 && chr < 58) {
                r.append(chr);
                z++;
                if (z > 10) {
                    break;
                }
            }
            if (chr == '.' || chr == ',') {
                break;
            }
        }
        return (Integer.parseInt(r.toString()));
    }
}
